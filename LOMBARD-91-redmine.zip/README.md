LOMBARD-91 - Redmine építőipari rendszer (ingyenes)
==================================================

Default access after first deploy:
- URL: https://redmine-lombard91.onrender.com  (example)
- admin / Admin123!

This package is prepared for free deployment on Render.com or local Docker.
Follow INSTALL.md for step-by-step instructions.
