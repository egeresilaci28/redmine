INIT-DATA folder
----------------
This folder contains example initialization data (project templates, role definitions)
that you can import into Redmine after first deployment.

Steps:
1. Deploy Redmine and login as admin.
2. Use the Administration -> Settings and Plugins pages to verify installed plugins.
3. Use the provided CSV/YAML files (if present) to import sample projects and custom fields.
