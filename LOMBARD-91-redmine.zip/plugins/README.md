Plugins folder
--------------
Place plugin folders here. The package includes placeholders for recommended free plugins:
- redmine_checklists
- redmine_crm_light
- redmine_finance_light
- redmine_agile_light
- redmine_hours

To add real plugins:
1. Clone each plugin into this directory (git clone <plugin-repo> plugins/<plugin-name>)
2. Run bundle install and rake redmine:plugins:migrate RAILS_ENV=production
3. Restart the app
