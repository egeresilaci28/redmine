LOMBARD-91 Redmine deployment (Render / local Docker)
====================================================

What is included
- Dockerfile (based on official Redmine image)
- docker-compose.yml for local testing
- .env.example with PostgreSQL sample credentials
- init-data/ sample project template
- plugins/ placeholders for recommended free plugins
- files/ for attachments

Quick start (local Docker testing)
---------------------------------
1. Copy .env.example to .env and set POSTGRES_PASSWORD to a secure password.
2. On your machine with Docker installed, run:
     docker-compose up --build
3. Visit http://localhost:3000
4. Default admin account (after install):
     username: admin
     password: Admin123!

Render.com deployment notes (free-tier)
---------------------------------------
1. Create a free account on https://render.com
2. Create a new PostgreSQL instance (Free Plan) and note connection details.
3. Create a new Web Service and connect it to this repository (or upload files).
   - Use Docker as the environment.
   - Set environment variables from your DB instance (POSTGRES_*).
4. Deploy. After deployment:
   - Login with admin/Admin123! and change the password immediately.
   - Go to "My account" -> "Language" and select "Magyar".
   - Install and enable plugins via Administration -> Plugins (for real plugins, clone them into plugins/ and run migrations).
   - Import the sample project from init-data by manually recreating or using CSV import tools.

Recommended post-install steps
------------------------------
- Create user accounts for your team:
   * 3 projectvezető (project lead) users
   * 3 művezető (site manager) users
   * 2 irodai munkatárs (office) users
- Configure Roles and Permissions under Administration -> Roles
- Add custom fields (Anyagköltség, Munkaidő, Gépóra, Alvállalkozó)
- Create a project using the sample template

Support
-------
If you want, I can:
- provide the real plugin git URLs and add them to the repo,
- or push this package as a GitHub repository for you and help connect Render.
